plugins {
    id("com.android.application")
}
android {
    namespace = "app.dlnatv"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.dlnatv"
        minSdk = 19
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    lint { abortOnError = false }
}

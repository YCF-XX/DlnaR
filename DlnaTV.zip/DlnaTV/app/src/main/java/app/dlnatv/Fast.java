package app.dlnatv;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.view.Surface;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Low-latency player: reads the live MPEG-TS over HTTP itself, demuxes H.264 + AAC and feeds
 * MediaCodec directly. No player-side buffering, and it always drops old frames instead of lagging.
 */
final class Fast {
    interface Listener {
        void onSize(int w, int h);
        void onFirstFrame();
        void onFail(String why);
        void onStats(String s);
    }

    private static final class Au {
        final byte[] data;
        final boolean key;
        Au(byte[] d, boolean k) { data = d; key = k; }
    }

    private static final class Pes {
        final int kind; // 1 video, 2 audio
        byte[] data = new byte[1 << 16];
        int len;
        int expect = -1;
        Pes(int kind) { this.kind = kind; }
        void add(byte[] b, int off, int n) {
            if (len + n > (8 << 20)) { len = 0; return; }
            if (len + n > data.length) data = Arrays.copyOf(data, Math.max(data.length * 2, len + n));
            System.arraycopy(b, off, data, len, n);
            len += n;
        }
    }

    private static final class Bits {
        final byte[] b;
        int pos;
        Bits(byte[] b) { this.b = b; }
        int bit() {
            int by = pos >> 3;
            if (by >= b.length) throw new IllegalStateException("sps eof");
            int r = (b[by] >> (7 - (pos & 7))) & 1;
            pos++;
            return r;
        }
        int u(int n) {
            int v = 0;
            for (int i = 0; i < n; i++) v = (v << 1) | bit();
            return v;
        }
        int ue() {
            int z = 0;
            while (bit() == 0) {
                z++;
                if (z > 31) throw new IllegalStateException("bad ue");
            }
            return z == 0 ? 0 : ((1 << z) - 1 + u(z));
        }
        int se() {
            int k = ue();
            return (k & 1) == 1 ? (k + 1) / 2 : -(k / 2);
        }
    }

    private static final int[] SR = {96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};

    private final String url;
    private final Surface surface;
    private final Listener ls;
    private volatile boolean run = true;
    private volatile Socket sock;
    private final Map<Integer, Pes> pes = new HashMap<Integer, Pes>();
    private final ArrayBlockingQueue<Au> vq = new ArrayBlockingQueue<Au>(6);
    private final ArrayBlockingQueue<byte[]> aq = new ArrayBlockingQueue<byte[]>(80);
    private boolean vStarted, gotKey, dropping, aStarted;
    private volatile int dropped;
    private int vw, vh;

    Fast(String url, Surface surface, Listener ls) {
        this.url = url;
        this.surface = surface;
        this.ls = ls;
    }

    void start() {
        Thread t = new Thread(new Runnable() { public void run() { netLoop(); } });
        t.setDaemon(true);
        t.start();
    }

    void stop() {
        run = false;
        try { if (sock != null) sock.close(); } catch (Exception e) { /* ignore */ }
    }

    private void fail(String why) {
        if (run) {
            run = false;
            ls.onFail(why);
        }
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        if (c < 0 && sb.length() == 0) return null;
        return sb.toString();
    }

    // ---------------- network + TS demux ----------------

    private void netLoop() {
        Socket s = null;
        try {
            URL u = new URL(url);
            int port = u.getPort() > 0 ? u.getPort() : 80;
            String path = u.getFile();
            if (path == null || path.isEmpty()) path = "/";
            s = new Socket();
            sock = s;
            s.setTcpNoDelay(true);
            s.setReceiveBufferSize(1 << 18);
            s.connect(new InetSocketAddress(u.getHost(), port), 5000);
            s.setSoTimeout(5000);
            OutputStream os = s.getOutputStream();
            os.write(("GET " + path + " HTTP/1.1\r\nHost: " + u.getHost() + ":" + port
                    + "\r\nConnection: close\r\nUser-Agent: DlnaTV\r\n\r\n").getBytes("UTF-8"));
            os.flush();
            InputStream in = s.getInputStream();
            String status = readLine(in);
            if (status == null || !status.contains(" 200")) { fail("HTTP " + status); return; }
            String l;
            boolean chunked = false;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                String lc = l.toLowerCase(Locale.US);
                if (lc.startsWith("transfer-encoding") && lc.contains("chunked")) chunked = true;
            }
            if (chunked) { fail("chunked stream"); return; }
            s.setSoTimeout(40);

            byte[] buf = new byte[188 * 96];
            int have = 0;
            long t0 = System.currentTimeMillis();
            while (run) {
                if (!vStarted && System.currentTimeMillis() - t0 > 8000) { fail("no video found"); return; }
                int n;
                try {
                    n = in.read(buf, have, buf.length - have);
                } catch (SocketTimeoutException e) {
                    idleFlush();
                    continue;
                }
                if (n < 0) break;
                have += n;
                int off = 0;
                while (have - off >= 188) {
                    if (buf[off] != 0x47) { off++; continue; }
                    packet(buf, off);
                    off += 188;
                }
                if (off > 0) {
                    System.arraycopy(buf, off, buf, 0, have - off);
                    have -= off;
                }
            }
            fail("stream ended");
        } catch (Throwable e) {
            fail(e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            try { if (s != null) s.close(); } catch (Exception e) { /* ignore */ }
        }
    }

    private void idleFlush() {
        for (Pes e : pes.values()) {
            if (e.kind == 1 && e.len > 0) flushVideo(e);
        }
    }

    private void packet(byte[] buf, int off) {
        int b1 = buf[off + 1] & 0xFF;
        int b3 = buf[off + 3] & 0xFF;
        boolean start = (b1 & 0x40) != 0;
        int pid = ((b1 & 0x1F) << 8) | (buf[off + 2] & 0xFF);
        int afc = (b3 >> 4) & 3;
        int p = off + 4;
        if ((afc & 2) != 0) p += 1 + (buf[p] & 0xFF);
        int end = off + 188;
        if ((afc & 1) == 0 || p >= end) return;
        if (pid == 0 || pid == 0x1FFF) return;
        Pes e = pes.get(pid);
        if (start) {
            if (end - p < 9 || buf[p] != 0 || buf[p + 1] != 0 || buf[p + 2] != 1) return;
            int sid = buf[p + 3] & 0xFF;
            int kind = (sid >= 0xE0 && sid <= 0xEF) ? 1 : (sid >= 0xC0 && sid <= 0xDF) ? 2 : 0;
            if (kind == 0) return;
            if (e == null || e.kind != kind) {
                e = new Pes(kind);
                pes.put(pid, e);
            } else if (kind == 1) {
                flushVideo(e);
            }
            int plen = ((buf[p + 4] & 0xFF) << 8) | (buf[p + 5] & 0xFF);
            int hl = buf[p + 8] & 0xFF;
            e.expect = plen > 0 ? plen - 3 - hl : -1;
            int es = p + 9 + hl;
            if (es < end) e.add(buf, es, end - es);
        } else if (e != null) {
            e.add(buf, p, end - p);
        } else {
            return;
        }
        if (e.kind == 2) drainAdts(e);
        else if (e.expect > 0 && e.len >= e.expect) flushVideo(e);
    }

    // ---------------- video ----------------

    private static int trim(byte[] d, int s, int e) {
        while (e > s && d[e - 1] == 0) e--;
        return e;
    }

    private static byte[] withStart(byte[] d, int s, int e) {
        byte[] r = new byte[4 + (e - s)];
        r[3] = 1;
        System.arraycopy(d, s, r, 4, e - s);
        return r;
    }

    private void flushVideo(Pes e) {
        if (e.len <= 0) return;
        byte[] d = e.data;
        int len = e.len;
        e.len = 0;
        e.expect = -1;

        ArrayList<int[]> nals = new ArrayList<int[]>();
        int ps = -1;
        for (int i = 0; i + 3 <= len; i++) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) {
                if (ps >= 0) nals.add(new int[]{d[ps] & 0x1F, ps, trim(d, ps, i)});
                ps = i + 3;
                i += 2;
            }
        }
        if (ps >= 0 && ps < len) nals.add(new int[]{d[ps] & 0x1F, ps, trim(d, ps, len)});

        boolean key = false;
        byte[] sps = null, pps = null;
        for (int[] n : nals) {
            if (n[0] == 5) key = true;
            else if (n[0] == 7 && sps == null) sps = withStart(d, n[1], n[2]);
            else if (n[0] == 8 && pps == null) pps = withStart(d, n[1], n[2]);
        }
        if (!vStarted) {
            if (sps == null || pps == null) return;
            startVideo(sps, pps);
            if (!vStarted) return;
        }
        if (!gotKey) {
            if (!key) return;
            gotKey = true;
        }
        Au au = new Au(Arrays.copyOf(d, len), key);
        if (key) {
            dropping = false;
            if (!vq.offer(au)) { vq.clear(); vq.offer(au); }
        } else if (!dropping) {
            if (!vq.offer(au)) {
                // decoder is behind: drop the backlog and wait for the next key frame
                dropping = true;
                vq.clear();
                dropped++;
            }
        } else {
            dropped++;
        }
    }

    private static int[] parseSps(byte[] n) {
        byte[] r = new byte[n.length];
        int rl = 0, zeros = 0;
        for (int i = 5; i < n.length; i++) { // 4 start-code bytes + 1 NAL header byte
            int c = n[i] & 0xFF;
            if (zeros >= 2 && c == 3) { zeros = 0; continue; }
            r[rl++] = (byte) c;
            zeros = c == 0 ? zeros + 1 : 0;
        }
        Bits b = new Bits(Arrays.copyOf(r, rl));
        int profile = b.u(8);
        b.u(8);
        b.u(8);
        b.ue();
        int chroma = 1;
        if (profile == 100 || profile == 110 || profile == 122 || profile == 244 || profile == 44 || profile == 83
                || profile == 86 || profile == 118 || profile == 128 || profile == 138 || profile == 139
                || profile == 134 || profile == 135) {
            chroma = b.ue();
            if (chroma == 3) b.u(1);
            b.ue();
            b.ue();
            b.u(1);
            if (b.u(1) == 1) {
                int cnt = chroma != 3 ? 8 : 12;
                for (int i = 0; i < cnt; i++) {
                    if (b.u(1) == 1) {
                        int size = i < 6 ? 16 : 64;
                        int last = 8, next = 8;
                        for (int j = 0; j < size; j++) {
                            if (next != 0) next = (last + b.se() + 256) % 256;
                            last = next == 0 ? last : next;
                        }
                    }
                }
            }
        }
        b.ue();
        int poc = b.ue();
        if (poc == 0) {
            b.ue();
        } else if (poc == 1) {
            b.u(1);
            b.se();
            b.se();
            int c = b.ue();
            for (int i = 0; i < c; i++) b.se();
        }
        b.ue();
        b.u(1);
        int wm = b.ue();
        int hm = b.ue();
        int fmo = b.u(1);
        if (fmo == 0) b.u(1);
        b.u(1);
        int cl = 0, cr = 0, ct = 0, cb = 0;
        if (b.u(1) == 1) { cl = b.ue(); cr = b.ue(); ct = b.ue(); cb = b.ue(); }
        int cux = chroma == 0 ? 1 : 2;
        int cuy = (chroma == 0 ? 1 : 2) * (2 - fmo);
        int w = (wm + 1) * 16 - cux * (cl + cr);
        int h = (2 - fmo) * (hm + 1) * 16 - cuy * (ct + cb);
        return new int[]{w, h};
    }

    private void startVideo(byte[] sps, byte[] pps) {
        try {
            int[] wh = parseSps(sps);
            int w = wh[0], h = wh[1];
            if (w < 16 || h < 16 || w > 4096 || h > 4096) throw new IllegalStateException("bad size " + w + "x" + h);
            MediaFormat f = MediaFormat.createVideoFormat("video/avc", w, h);
            f.setByteBuffer("csd-0", ByteBuffer.wrap(sps));
            f.setByteBuffer("csd-1", ByteBuffer.wrap(pps));
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 20);
            final MediaCodec d = MediaCodec.createDecoderByType("video/avc");
            d.configure(f, surface, null, 0);
            d.start();
            vw = w;
            vh = h;
            vStarted = true;
            ls.onSize(w, h);
            Thread t = new Thread(new Runnable() { public void run() { videoLoop(d); } });
            t.setDaemon(true);
            t.start();
        } catch (Throwable t) {
            fail("video decoder: " + t.getClass().getSimpleName() + " " + t.getMessage());
        }
    }

    private void videoLoop(MediaCodec d) {
        ByteBuffer[] in = d.getInputBuffers();
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        long n = 0;
        int fpsCount = 0;
        boolean first = false;
        long statT = System.currentTimeMillis();
        try {
            while (run) {
                Au a = vq.poll(50, TimeUnit.MILLISECONDS);
                if (a != null) {
                    int idx = d.dequeueInputBuffer(a.key ? 100000 : 15000);
                    if (idx >= 0 && a.data.length <= in[idx].capacity()) {
                        in[idx].clear();
                        in[idx].put(a.data, 0, a.data.length);
                        d.queueInputBuffer(idx, 0, a.data.length, n * 33333, 0);
                        n++;
                    } else if (!a.key) {
                        dropped++;
                    }
                }
                int oi;
                while ((oi = d.dequeueOutputBuffer(bi, 0)) >= 0) {
                    d.releaseOutputBuffer(oi, true);
                    fpsCount++;
                    if (!first) {
                        first = true;
                        ls.onFirstFrame();
                    }
                }
                long now = System.currentTimeMillis();
                if (now - statT >= 1000) {
                    ls.onStats("FAST " + vw + "x" + vh + "   " + fpsCount + " fps   dropped " + dropped);
                    fpsCount = 0;
                    statT = now;
                }
            }
        } catch (Throwable t) {
            fail("decode: " + t.getClass().getSimpleName() + " " + t.getMessage());
        } finally {
            try { d.stop(); } catch (Exception e) { /* ignore */ }
            try { d.release(); } catch (Exception e) { /* ignore */ }
        }
    }

    // ---------------- audio ----------------

    private void drainAdts(Pes e) {
        byte[] d = e.data;
        int pos = 0;
        while (e.len - pos >= 7) {
            if ((d[pos] & 0xFF) != 0xFF || (d[pos + 1] & 0xF0) != 0xF0) { pos++; continue; }
            int flen = ((d[pos + 3] & 3) << 11) | ((d[pos + 4] & 0xFF) << 3) | ((d[pos + 5] & 0xE0) >> 5);
            if (flen < 7) { pos++; continue; }
            if (e.len - pos < flen) break;
            int hdr = (d[pos + 1] & 1) == 1 ? 7 : 9;
            audioFrame(d, pos, hdr, flen);
            pos += flen;
        }
        if (pos > 0) {
            System.arraycopy(d, pos, d, 0, e.len - pos);
            e.len -= pos;
        }
    }

    private void audioFrame(byte[] d, int pos, int hdr, int flen) {
        if (!aStarted) {
            startAudio(d, pos);
            if (!aStarted) return;
        }
        byte[] f = Arrays.copyOfRange(d, pos + hdr, pos + flen);
        if (!aq.offer(f)) {
            aq.poll();
            aq.offer(f);
        }
    }

    private void startAudio(byte[] d, int p) {
        try {
            int obj = ((d[p + 2] & 0xC0) >> 6) + 1;
            int sf = (d[p + 2] & 0x3C) >> 2;
            int ch = ((d[p + 2] & 1) << 2) | ((d[p + 3] & 0xC0) >> 6);
            if (sf >= SR.length || ch < 1 || ch > 2) return;
            int sr = SR[sf];
            byte[] asc = {(byte) ((obj << 3) | (sf >> 1)), (byte) (((sf & 1) << 7) | (ch << 3))};
            MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", sr, ch);
            f.setByteBuffer("csd-0", ByteBuffer.wrap(asc));
            final MediaCodec dec = MediaCodec.createDecoderByType("audio/mp4a-latm");
            dec.configure(f, null, null, 0);
            dec.start();
            int mask = ch == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int min = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_16BIT);
            final AudioTrack tr = new AudioTrack(AudioManager.STREAM_MUSIC, sr, mask,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, 4096), AudioTrack.MODE_STREAM);
            tr.play();
            aStarted = true;
            Thread t = new Thread(new Runnable() { public void run() { audioLoop(dec, tr); } });
            t.setDaemon(true);
            t.start();
        } catch (Throwable t) {
            /* continue without audio */
        }
    }

    private void audioLoop(MediaCodec dec, AudioTrack tr) {
        ByteBuffer[] in = dec.getInputBuffers();
        ByteBuffer[] out = dec.getOutputBuffers();
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        try {
            while (run) {
                byte[] f = aq.poll(100, TimeUnit.MILLISECONDS);
                if (f == null) continue;
                while (aq.size() > 30) aq.poll(); // keep audio latency bounded
                int idx = dec.dequeueInputBuffer(20000);
                if (idx >= 0 && f.length <= in[idx].capacity()) {
                    in[idx].clear();
                    in[idx].put(f);
                    dec.queueInputBuffer(idx, 0, f.length, 0, 0);
                }
                while (true) {
                    int oi = dec.dequeueOutputBuffer(bi, 0);
                    if (oi >= 0) {
                        ByteBuffer ob = out[oi];
                        byte[] pcm = new byte[bi.size];
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        ob.get(pcm);
                        tr.write(pcm, 0, pcm.length);
                        dec.releaseOutputBuffer(oi, false);
                    } else if (oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                        out = dec.getOutputBuffers();
                    } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break;
                    }
                }
            }
        } catch (Throwable t) {
            /* audio stops, video continues */
        } finally {
            try { tr.stop(); } catch (Exception e) { /* ignore */ }
            try { tr.release(); } catch (Exception e) { /* ignore */ }
            try { dec.stop(); } catch (Exception e) { /* ignore */ }
            try { dec.release(); } catch (Exception e) { /* ignore */ }
        }
    }
}

package app.dlnatv;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.view.Surface;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Low-latency player for the live MPEG-TS of DlnaCast: reads the stream itself, demuxes H.264 + AAC
 * and feeds MediaCodec directly.
 *
 * Sync: every frame carries a PTS taken from the sender's capture clock (audio and video share it).
 * The receiver maps that clock to its own with a sliding minimum of (arrival - PTS) and plays every
 * frame at  minOffset + D + PTS , where D is a small playout delay that adapts to Wi-Fi jitter.
 * Audio and video use the same schedule, so they stay aligned without any manual setting.
 */
final class Fast {
    interface Listener {
        void onSize(int w, int h);
        void onFirstFrame();
        void onFail(String why);
    }

    private static final class Au {
        final byte[] data;
        final boolean key;
        final long pts; // ms on the sender clock, -1 = unknown
        Au(byte[] d, boolean k, long pts) { data = d; key = k; this.pts = pts; }
    }

    private static final class Af {
        final byte[] d;
        final long pts;
        Af(byte[] d, long pts) { this.d = d; this.pts = pts; }
    }

    private static final class Pes {
        final int kind; // 1 video, 2 audio
        byte[] data = new byte[1 << 16];
        int len;
        int expect = -1;
        long pts = -1;
        int n; // audio frames already taken from this PES
        Pes(int kind) { this.kind = kind; }
        void add(byte[] b, int off, int n) {
            if (len + n > (8 << 20)) { len = 0; return; }
            if (len + n > data.length) data = Arrays.copyOf(data, Math.max(data.length * 2, len + n));
            System.arraycopy(b, off, data, len, n);
            len += n;
        }
    }

    private static final class Bits {
        final byte[] b;
        int pos;
        Bits(byte[] b) { this.b = b; }
        int bit() {
            int by = pos >> 3;
            if (by >= b.length) throw new IllegalStateException("sps eof");
            int r = (b[by] >> (7 - (pos & 7))) & 1;
            pos++;
            return r;
        }
        int u(int n) {
            int v = 0;
            for (int i = 0; i < n; i++) v = (v << 1) | bit();
            return v;
        }
        int ue() {
            int z = 0;
            while (bit() == 0) {
                z++;
                if (z > 31) throw new IllegalStateException("bad ue");
            }
            return z == 0 ? 0 : ((1 << z) - 1 + u(z));
        }
        int se() {
            int k = ue();
            return (k & 1) == 1 ? (k + 1) / 2 : -(k / 2);
        }
    }

    private static final int[] SR = {96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    private static final int FEED_LEAD = 35;   // ms the video decoder needs before the frame is due
    private static final int AUDIO_LEAD = 40;  // ms of audio output latency

    private final String url;
    private final Surface surface;
    private final Listener ls;
    private volatile boolean run = true;
    private volatile Socket sock;
    private final Map<Integer, Pes> pes = new HashMap<Integer, Pes>();
    private final ArrayBlockingQueue<Au> vq = new ArrayBlockingQueue<Au>(64);
    private final ArrayBlockingQueue<Af> aq = new ArrayBlockingQueue<Af>(120);
    private boolean vStarted, gotKey, aStarted;
    private volatile boolean skipToKey;
    private volatile double aFrameMs = 21.333;

    // ---- sender clock -> local clock ----
    private final Object clk = new Object();
    private long winMin = Long.MAX_VALUE, prevMin = Long.MAX_VALUE, winStart, lastPts = Long.MIN_VALUE;
    private volatile long minOff = Long.MIN_VALUE;
    private volatile int delayMs = 200;          // D: playout delay, adapts to jitter
    private volatile long connectMs;
    private long statT, lastLate;
    private int lateCount;

    Fast(String url, Surface surface, Listener ls) {
        this.url = url;
        this.surface = surface;
        this.ls = ls;
    }

    void start() {
        Thread t = new Thread(new Runnable() { public void run() { netLoop(); } });
        t.setDaemon(true);
        t.start();
    }

    void stop() {
        run = false;
        try { if (sock != null) sock.close(); } catch (Exception e) { /* ignore */ }
    }

    private void fail(String why) {
        if (run) {
            run = false;
            ls.onFail(why);
        }
    }

    private static long now() { return System.nanoTime() / 1000000L; }

    private void observe(long arrival, long pts) {
        if (pts < 0) return;
        synchronized (clk) {
            if (lastPts != Long.MIN_VALUE && (pts < lastPts - 3000 || pts > lastPts + 15000)) {
                winMin = Long.MAX_VALUE;   // new session / clock jump: start over
                prevMin = Long.MAX_VALUE;
                minOff = Long.MIN_VALUE;
                winStart = 0;
            }
            lastPts = pts;
            if (winStart == 0 || arrival - winStart > 4000) {
                prevMin = winMin;
                winMin = Long.MAX_VALUE;
                winStart = arrival;
            }
            long off = arrival - pts;
            if (off < winMin) winMin = off;
            minOff = Math.min(winMin, prevMin);
        }
    }

    private long due(long pts, long t) {
        long m = minOff;
        if (m == Long.MIN_VALUE || pts < 0) return t;
        return m + delayMs + pts;
    }

    private synchronized void noteLate(long t, long lateMs) {
        if (t - connectMs < 3000) return; // ignore the catch-up burst at the start
        if (lateMs > 30 && lateMs < 400) {
            lateCount++;
            lastLate = t;
        }
    }

    private synchronized void adapt(long t) {
        if (t - statT < 2000) return;
        statT = t;
        if (lateCount >= 3 && delayMs < 800) delayMs += 40;
        else if (t - lastLate > 10000 && delayMs > 120) delayMs -= 10;
        lateCount = 0;
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        if (c < 0 && sb.length() == 0) return null;
        return sb.toString();
    }

    // ---------------- network + TS demux ----------------

    private void netLoop() {
        Socket s = null;
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
            URL u = new URL(url);
            int port = u.getPort() > 0 ? u.getPort() : 80;
            String path = u.getFile();
            if (path == null || path.isEmpty()) path = "/";
            s = new Socket();
            sock = s;
            s.setTcpNoDelay(true);
            s.setReceiveBufferSize(1 << 18);
            s.connect(new InetSocketAddress(u.getHost(), port), 5000);
            s.setSoTimeout(5000);
            OutputStream os = s.getOutputStream();
            os.write(("GET " + path + " HTTP/1.1\r\nHost: " + u.getHost() + ":" + port
                    + "\r\nConnection: close\r\nUser-Agent: DlnaTV\r\n\r\n").getBytes("UTF-8"));
            os.flush();
            InputStream in = s.getInputStream();
            String status = readLine(in);
            if (status == null || !status.contains(" 200")) { fail("HTTP " + status); return; }
            String l;
            boolean chunked = false;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                String lc = l.toLowerCase(Locale.US);
                if (lc.startsWith("transfer-encoding") && lc.contains("chunked")) chunked = true;
            }
            if (chunked) { fail("chunked stream"); return; }
            s.setSoTimeout(40);

            byte[] buf = new byte[188 * 96];
            int have = 0;
            long t0 = System.currentTimeMillis();
            int idle = 0;
            while (run) {
                if (!vStarted && System.currentTimeMillis() - t0 > 8000) { fail("no video found"); return; }
                int n;
                try {
                    n = in.read(buf, have, buf.length - have);
                } catch (SocketTimeoutException e) {
                    if (++idle == 6) idleFlush(); // last frame, after ~240 ms of silence
                    continue;
                }
                idle = 0;
                if (n < 0) break;
                have += n;
                int off = 0;
                while (have - off >= 188) {
                    if (buf[off] != 0x47) { off++; continue; }
                    packet(buf, off);
                    off += 188;
                }
                if (off > 0) {
                    System.arraycopy(buf, off, buf, 0, have - off);
                    have -= off;
                }
            }
            fail("stream ended");
        } catch (Throwable e) {
            fail(e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            try { if (s != null) s.close(); } catch (Exception e) { /* ignore */ }
        }
    }

    private void idleFlush() {
        for (Pes e : pes.values()) {
            if (e.kind == 1 && e.len > 0) flushVideo(e);
        }
    }

    private void packet(byte[] buf, int off) {
        int b1 = buf[off + 1] & 0xFF;
        int b3 = buf[off + 3] & 0xFF;
        boolean start = (b1 & 0x40) != 0;
        int pid = ((b1 & 0x1F) << 8) | (buf[off + 2] & 0xFF);
        int afc = (b3 >> 4) & 3;
        int p = off + 4;
        boolean stuffing = false; // padding inside the adaptation field = last packet of a PES
        if ((afc & 2) != 0) {
            int alen = buf[p] & 0xFF;
            if (alen == 0) {
                stuffing = true;
            } else if (p + 1 < off + 188) {
                int fl = buf[p + 1] & 0xFF;
                int need = 1 + ((fl & 0x10) != 0 ? 6 : 0) + ((fl & 0x08) != 0 ? 6 : 0);
                stuffing = fl == 0 || alen > need; // PCR alone is not padding, PCR + extra bytes is
            }
            p += 1 + alen;
        }
        int end = off + 188;
        if ((afc & 1) == 0 || p >= end) return;
        if (pid == 0 || pid == 0x1FFF) return;
        Pes e = pes.get(pid);
        if (start) {
            if (end - p < 9 || buf[p] != 0 || buf[p + 1] != 0 || buf[p + 2] != 1) return;
            int sid = buf[p + 3] & 0xFF;
            int kind = (sid >= 0xE0 && sid <= 0xEF) ? 1 : (sid >= 0xC0 && sid <= 0xDF) ? 2 : 0;
            if (kind == 0) return;
            if (e == null || e.kind != kind) {
                e = new Pes(kind);
                pes.put(pid, e);
            } else if (kind == 1) {
                flushVideo(e);
            }
            int plen = ((buf[p + 4] & 0xFF) << 8) | (buf[p + 5] & 0xFF);
            int hl = buf[p + 8] & 0xFF;
            e.expect = plen > 0 ? plen - 3 - hl : -1;
            e.pts = -1;
            e.n = 0;
            if ((buf[p + 7] & 0x80) != 0 && end - p >= 14) {
                long v = ((buf[p + 9] & 0x0EL) << 29) | ((buf[p + 10] & 0xFFL) << 22) | ((buf[p + 11] & 0xFEL) << 14)
                        | ((buf[p + 12] & 0xFFL) << 7) | ((buf[p + 13] & 0xFFL) >> 1);
                e.pts = v / 90; // 90 kHz -> ms
            }
            int es = p + 9 + hl;
            if (es < end) e.add(buf, es, end - es);
        } else if (e != null) {
            e.add(buf, p, end - p);
        } else {
            return;
        }
        if (e.kind == 2) drainAdts(e);
        else if (stuffing || (e.expect > 0 && e.len >= e.expect)) flushVideo(e);
    }

    // ---------------- video ----------------

    private static int trim(byte[] d, int s, int e) {
        while (e > s && d[e - 1] == 0) e--;
        return e;
    }

    private static byte[] withStart(byte[] d, int s, int e) {
        byte[] r = new byte[4 + (e - s)];
        r[3] = 1;
        System.arraycopy(d, s, r, 4, e - s);
        return r;
    }

    private void flushVideo(Pes e) {
        if (e.len <= 0) return;
        byte[] d = e.data;
        int len = e.len;
        long pts = e.pts;
        e.len = 0;
        e.expect = -1;

        boolean key = false;
        int spsS = -1, spsE = -1, ppsS = -1, ppsE = -1;
        int ps = -1;
        for (int i = 0; i + 3 <= len; i++) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) {
                if (ps >= 0) {
                    int t = d[ps] & 0x1F;
                    if (t == 5) key = true;
                    else if (!vStarted && t == 7 && spsS < 0) { spsS = ps; spsE = trim(d, ps, i); }
                    else if (!vStarted && t == 8 && ppsS < 0) { ppsS = ps; ppsE = trim(d, ps, i); }
                }
                ps = i + 3;
                i += 2;
            }
        }
        if (ps >= 0 && ps < len) {
            int t = d[ps] & 0x1F;
            if (t == 5) key = true;
            else if (!vStarted && t == 7 && spsS < 0) { spsS = ps; spsE = trim(d, ps, len); }
            else if (!vStarted && t == 8 && ppsS < 0) { ppsS = ps; ppsE = trim(d, ps, len); }
        }

        observe(now(), pts);
        if (!vStarted) {
            if (spsS < 0 || ppsS < 0) return;
            startVideo(withStart(d, spsS, spsE), withStart(d, ppsS, ppsE));
            if (!vStarted) return;
        }
        if (!gotKey) {
            if (!key) return;
            gotKey = true;
        }
        if (key) {
            skipToKey = false;
            Au au = new Au(Arrays.copyOf(d, len), true, pts);
            if (!vq.offer(au)) { vq.clear(); vq.offer(au); }
        } else if (skipToKey) {
            // a frame was lost earlier: P-frames would only draw blocks until the next key frame
        } else if (!vq.offer(new Au(Arrays.copyOf(d, len), false, pts))) {
            skipToKey = true;
            vq.clear();
        }
    }

    private static int[] parseSps(byte[] n) {
        byte[] r = new byte[n.length];
        int rl = 0, zeros = 0;
        for (int i = 5; i < n.length; i++) { // 4 start-code bytes + 1 NAL header byte
            int c = n[i] & 0xFF;
            if (zeros >= 2 && c == 3) { zeros = 0; continue; }
            r[rl++] = (byte) c;
            zeros = c == 0 ? zeros + 1 : 0;
        }
        Bits b = new Bits(Arrays.copyOf(r, rl));
        int profile = b.u(8);
        b.u(8);
        b.u(8);
        b.ue();
        int chroma = 1;
        if (profile == 100 || profile == 110 || profile == 122 || profile == 244 || profile == 44 || profile == 83
                || profile == 86 || profile == 118 || profile == 128 || profile == 138 || profile == 139
                || profile == 134 || profile == 135) {
            chroma = b.ue();
            if (chroma == 3) b.u(1);
            b.ue();
            b.ue();
            b.u(1);
            if (b.u(1) == 1) {
                int cnt = chroma != 3 ? 8 : 12;
                for (int i = 0; i < cnt; i++) {
                    if (b.u(1) == 1) {
                        int size = i < 6 ? 16 : 64;
                        int last = 8, next = 8;
                        for (int j = 0; j < size; j++) {
                            if (next != 0) next = (last + b.se() + 256) % 256;
                            last = next == 0 ? last : next;
                        }
                    }
                }
            }
        }
        b.ue();
        int poc = b.ue();
        if (poc == 0) {
            b.ue();
        } else if (poc == 1) {
            b.u(1);
            b.se();
            b.se();
            int c = b.ue();
            for (int i = 0; i < c; i++) b.se();
        }
        b.ue();
        b.u(1);
        int wm = b.ue();
        int hm = b.ue();
        int fmo = b.u(1);
        if (fmo == 0) b.u(1);
        b.u(1);
        int cl = 0, cr = 0, ct = 0, cb = 0;
        if (b.u(1) == 1) { cl = b.ue(); cr = b.ue(); ct = b.ue(); cb = b.ue(); }
        int cux = chroma == 0 ? 1 : 2;
        int cuy = (chroma == 0 ? 1 : 2) * (2 - fmo);
        int w = (wm + 1) * 16 - cux * (cl + cr);
        int h = (2 - fmo) * (hm + 1) * 16 - cuy * (ct + cb);
        return new int[]{w, h};
    }

    private void startVideo(byte[] sps, byte[] pps) {
        try {
            int[] wh = parseSps(sps);
            int w = wh[0], h = wh[1];
            if (w < 16 || h < 16 || w > 4096 || h > 4096) throw new IllegalStateException("bad size " + w + "x" + h);
            MediaFormat f = MediaFormat.createVideoFormat("video/avc", w, h);
            f.setByteBuffer("csd-0", ByteBuffer.wrap(sps));
            f.setByteBuffer("csd-1", ByteBuffer.wrap(pps));
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 20);
            final MediaCodec d = MediaCodec.createDecoderByType("video/avc");
            d.configure(f, surface, null, 0);
            d.start();
            vStarted = true;
            connectMs = now();
            ls.onSize(w, h);
            Thread tin = new Thread(new Runnable() { public void run() { videoIn(d); } });
            tin.setDaemon(true);
            tin.start();
            Thread tout = new Thread(new Runnable() { public void run() { videoOut(d); } });
            tout.setDaemon(true);
            tout.start();
        } catch (Throwable ex) {
            fail("video decoder: " + ex.getClass().getSimpleName() + " " + ex.getMessage());
        }
    }

    /** Feeds the decoder so that each frame comes out just when it is due. */
    private void videoIn(MediaCodec d) {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        ByteBuffer[] in = d.getInputBuffers();
        long n = 0;
        try {
            while (run) {
                Au a = vq.poll(50, TimeUnit.MILLISECONDS);
                long tm = now();
                adapt(tm);
                if (a == null) continue;
                long due = due(a.pts, tm);
                long wait = due - FEED_LEAD - tm;
                if (wait > 0) Thread.sleep(Math.min(wait, 700));
                else noteLate(tm, -wait);
                int idx = d.dequeueInputBuffer(a.key ? 150000 : 33000);
                if (idx >= 0 && a.data.length <= in[idx].capacity()) {
                    in[idx].clear();
                    in[idx].put(a.data, 0, a.data.length);
                    long us = a.pts >= 0 ? a.pts * 1000 : n * 33333;
                    d.queueInputBuffer(idx, 0, a.data.length, us, 0);
                    n++;
                } else {
                    // the decoder could not take this frame: resync at the next key frame
                    skipToKey = true;
                    vq.clear();
                }
            }
        } catch (Throwable ex) {
            fail("decode: " + ex.getClass().getSimpleName() + " " + ex.getMessage());
        }
    }

    private void videoOut(MediaCodec d) {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        boolean first = false;
        try {
            while (run) {
                int oi = d.dequeueOutputBuffer(bi, 20000);
                if (oi >= 0) {
                    d.releaseOutputBuffer(oi, true);
                    if (!first) {
                        first = true;
                        ls.onFirstFrame();
                    }
                }
            }
        } catch (Throwable ex) {
            fail("decode: " + ex.getClass().getSimpleName() + " " + ex.getMessage());
        } finally {
            try { d.stop(); } catch (Exception e) { /* ignore */ }
            try { d.release(); } catch (Exception e) { /* ignore */ }
        }
    }

    // ---------------- audio ----------------

    private void drainAdts(Pes e) {
        byte[] d = e.data;
        int pos = 0;
        while (e.len - pos >= 7) {
            if ((d[pos] & 0xFF) != 0xFF || (d[pos + 1] & 0xF0) != 0xF0) { pos++; continue; }
            int flen = ((d[pos + 3] & 3) << 11) | ((d[pos + 4] & 0xFF) << 3) | ((d[pos + 5] & 0xE0) >> 5);
            if (flen < 7) { pos++; continue; }
            if (e.len - pos < flen) break;
            int hdr = (d[pos + 1] & 1) == 1 ? 7 : 9;
            long fp = e.pts < 0 ? -1 : e.pts + (long) (e.n * aFrameMs);
            e.n++;
            audioFrame(d, pos, hdr, flen, fp);
            pos += flen;
        }
        if (pos > 0) {
            System.arraycopy(d, pos, d, 0, e.len - pos);
            e.len -= pos;
        }
    }

    private void audioFrame(byte[] d, int pos, int hdr, int flen, long pts) {
        if (!aStarted) {
            startAudio(d, pos);
            if (!aStarted) return;
        }
        observe(now(), pts);
        Af f = new Af(Arrays.copyOfRange(d, pos + hdr, pos + flen), pts);
        if (!aq.offer(f)) {
            aq.poll();
            aq.offer(f);
        }
    }

    private void startAudio(byte[] d, int p) {
        try {
            int obj = ((d[p + 2] & 0xC0) >> 6) + 1;
            int sf = (d[p + 2] & 0x3C) >> 2;
            int ch = ((d[p + 2] & 1) << 2) | ((d[p + 3] & 0xC0) >> 6);
            if (sf >= SR.length || ch < 1 || ch > 2) return;
            int sr = SR[sf];
            aFrameMs = 1024000.0 / sr;
            byte[] asc = {(byte) ((obj << 3) | (sf >> 1)), (byte) (((sf & 1) << 7) | (ch << 3))};
            MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", sr, ch);
            f.setByteBuffer("csd-0", ByteBuffer.wrap(asc));
            final MediaCodec dec = MediaCodec.createDecoderByType("audio/mp4a-latm");
            dec.configure(f, null, null, 0);
            dec.start();
            int mask = ch == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int min = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_16BIT);
            final AudioTrack tr = new AudioTrack(AudioManager.STREAM_MUSIC, sr, mask,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, 4096), AudioTrack.MODE_STREAM);
            tr.play();
            aStarted = true;
            Thread t = new Thread(new Runnable() { public void run() { audioLoop(dec, tr); } });
            t.setDaemon(true);
            t.start();
        } catch (Throwable ex) {
            /* continue without audio */
        }
    }

    private void audioLoop(MediaCodec dec, AudioTrack tr) {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
        ByteBuffer[] in = dec.getInputBuffers();
        ByteBuffer[] out = dec.getOutputBuffers();
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        try {
            while (run) {
                Af a = aq.poll(100, TimeUnit.MILLISECONDS);
                if (a == null) continue;
                while (aq.size() > 40) aq.poll(); // keep audio latency bounded
                int idx = dec.dequeueInputBuffer(20000);
                if (idx >= 0 && a.d.length <= in[idx].capacity()) {
                    in[idx].clear();
                    in[idx].put(a.d);
                    dec.queueInputBuffer(idx, 0, a.d.length, a.pts >= 0 ? a.pts * 1000 : 0, 0);
                }
                while (true) {
                    int oi = dec.dequeueOutputBuffer(bi, 0);
                    if (oi >= 0) {
                        long p = bi.presentationTimeUs > 0 ? bi.presentationTimeUs / 1000 : a.pts;
                        ByteBuffer ob = out[oi];
                        byte[] pcm = new byte[bi.size];
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        ob.get(pcm);
                        dec.releaseOutputBuffer(oi, false);
                        long tm = now();
                        long due = due(p, tm);
                        if (p >= 0 && due < tm - 120) { // too old (start-up backlog or a stall): skip it
                            noteLate(tm, tm - due);
                            continue;
                        }
                        long wait = due - AUDIO_LEAD - tm;
                        if (wait > 0) Thread.sleep(Math.min(wait, 800));
                        tr.write(pcm, 0, pcm.length);
                    } else if (oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                        out = dec.getOutputBuffers();
                    } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break;
                    }
                }
            }
        } catch (Throwable ex) {
            /* audio stops, video continues */
        } finally {
            try { tr.stop(); } catch (Exception e) { /* ignore */ }
            try { tr.release(); } catch (Exception e) { /* ignore */ }
            try { dec.stop(); } catch (Exception e) { /* ignore */ }
            try { dec.release(); } catch (Exception e) { /* ignore */ }
        }
    }
}

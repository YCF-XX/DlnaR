package app.dlnatv;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Minimal UPnP/DLNA MediaRenderer: SSDP + device description + AVTransport/RenderingControl/ConnectionManager. */
final class Upnp {
    interface Host {
        void setUri(String uri);
        void play();
        void pause();
        void stop();
        void seek(long ms);
        String state();
        long positionMs();
        long durationMs();
        String uri();
        int volume();
        void setVolume(int v);
        boolean mute();
        void setMute(boolean m);
    }

    static final String GROUP = "239.255.255.250";
    static final int SSDP_PORT = 1900;
    static final String SERVER = "Linux/3.0 UPnP/1.0 DlnaTV/1.0";
    static final String AVT = "urn:schemas-upnp-org:service:AVTransport:1";
    static final String RCS = "urn:schemas-upnp-org:service:RenderingControl:1";
    static final String CMS = "urn:schemas-upnp-org:service:ConnectionManager:1";
    static final String DEV = "urn:schemas-upnp-org:device:MediaRenderer:1";
    static final String SINK = "http-get:*:video/mpeg:*,http-get:*:video/mp2t:*,http-get:*:video/mp4:*,"
            + "http-get:*:video/x-matroska:*,http-get:*:video/avi:*,http-get:*:audio/mpeg:*,http-get:*:audio/mp4:*,"
            + "http-get:*:audio/x-wav:*";

    private final Host host;
    private final String uuid;
    private final String name;
    private final int port;
    private volatile boolean run;
    private String ip = "0.0.0.0";
    volatile String error = "";
    private ServerSocket http;
    private MulticastSocket ssdp;
    private DatagramSocket out;
    private WifiManager.MulticastLock lock;
    private final String[] targets;

    Upnp(Host host, String uuid, String name, int port) {
        this.host = host;
        this.uuid = uuid;
        this.name = name;
        this.port = port;
        targets = new String[]{"upnp:rootdevice", "uuid:" + uuid, DEV, AVT, RCS, CMS};
    }

    String ip() { return ip; }

    private static void thread(Runnable r) {
        Thread t = new Thread(r);
        t.setDaemon(true);
        t.start();
    }

    void start(Context ctx) {
        run = true;
        ip = localIp();
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            lock = wm.createMulticastLock("dlnatv");
            lock.setReferenceCounted(false);
            lock.acquire();
        } catch (Exception e) { /* ignore */ }
        thread(new Runnable() { public void run() { httpLoop(); } });
        thread(new Runnable() { public void run() { ssdpLoop(); } });
        thread(new Runnable() { public void run() { notifyLoop(); } });
    }

    void stop() {
        run = false;
        thread(new Runnable() {
            public void run() {
                try { sendNotify("ssdp:byebye"); } catch (Exception e) { /* ignore */ }
                try { if (ssdp != null) ssdp.close(); } catch (Exception e) { /* ignore */ }
                try { if (http != null) http.close(); } catch (Exception e) { /* ignore */ }
                try { if (lock != null) lock.release(); } catch (Exception e) { /* ignore */ }
            }
        });
    }

    static String localIp() {
        String fallback = "0.0.0.0";
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        String n = ni.getName();
                        if (n.startsWith("wlan") || n.startsWith("eth")) return a.getHostAddress();
                        fallback = a.getHostAddress();
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return fallback;
    }

    // ---------------- SSDP ----------------

    private String usn(String t) {
        return t.equals("uuid:" + uuid) ? t : "uuid:" + uuid + "::" + t;
    }

    private String location() { return "http://" + ip + ":" + port + "/desc.xml"; }

    private void ssdpLoop() {
        try {
            ssdp = new MulticastSocket((SocketAddress) null);
            ssdp.setReuseAddress(true);
            ssdp.bind(new InetSocketAddress(SSDP_PORT));
            InetAddress g = InetAddress.getByName(GROUP);
            boolean joined = false;
            try {
                for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp() || ni.isLoopback() || !ni.supportsMulticast()) continue;
                    try {
                        ssdp.joinGroup(new InetSocketAddress(g, SSDP_PORT), ni);
                        joined = true;
                    } catch (Exception e) { /* try next */ }
                }
            } catch (Exception e) { /* ignore */ }
            if (!joined) ssdp.joinGroup(g);
            if (out == null) out = new DatagramSocket();
            byte[] buf = new byte[2048];
            while (run) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                ssdp.receive(p);
                String s = new String(p.getData(), 0, p.getLength(), "UTF-8");
                if (s.startsWith("M-SEARCH")) {
                    String st = header(s, "ST");
                    if (st != null) respond(st.trim(), p.getAddress(), p.getPort());
                }
            }
        } catch (Exception e) {
            if (run) error = "SSDP: " + e.getMessage();
        }
    }

    private static String header(String msg, String name) {
        for (String line : msg.split("\r\n")) {
            int c = line.indexOf(':');
            if (c > 0 && line.substring(0, c).trim().equalsIgnoreCase(name)) return line.substring(c + 1).trim();
        }
        return null;
    }

    private void respond(String st, InetAddress to, int toPort) throws Exception {
        for (String t : targets) {
            if (st.equals("ssdp:all") || st.equals(t)) {
                String m = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\nLOCATION: " + location()
                        + "\r\nSERVER: " + SERVER + "\r\nST: " + t + "\r\nUSN: " + usn(t) + "\r\n\r\n";
                byte[] b = m.getBytes("UTF-8");
                if (out == null) out = new DatagramSocket();
                out.send(new DatagramPacket(b, b.length, to, toPort));
            }
        }
    }

    private void sendNotify(String nts) throws Exception {
        if (out == null) out = new DatagramSocket();
        InetAddress g = InetAddress.getByName(GROUP);
        for (String t : targets) {
            String m = "NOTIFY * HTTP/1.1\r\nHOST: " + GROUP + ":" + SSDP_PORT + "\r\nCACHE-CONTROL: max-age=1800\r\n"
                    + "LOCATION: " + location() + "\r\nNT: " + t + "\r\nNTS: " + nts + "\r\nSERVER: " + SERVER
                    + "\r\nUSN: " + usn(t) + "\r\n\r\n";
            byte[] b = m.getBytes("UTF-8");
            out.send(new DatagramPacket(b, b.length, g, SSDP_PORT));
        }
    }

    private void notifyLoop() {
        try {
            while (run) {
                try { sendNotify("ssdp:alive"); } catch (Exception e) { /* network not ready yet */ }
                Thread.sleep(15000);
            }
        } catch (InterruptedException e) { /* stop */ }
    }

    // ---------------- HTTP ----------------

    private void httpLoop() {
        try {
            http = new ServerSocket();
            http.setReuseAddress(true);
            http.bind(new InetSocketAddress(port));
            while (run) {
                final Socket s = http.accept();
                thread(new Runnable() { public void run() { handle(s); } });
            }
        } catch (Exception e) {
            if (run) error = "HTTP: " + e.getMessage();
        }
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        if (c < 0 && sb.length() == 0) return null;
        return sb.toString();
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            String line = readLine(in);
            if (line == null || line.isEmpty()) return;
            String[] rl = line.split(" ");
            String method = rl[0];
            String path = rl.length > 1 ? rl[1] : "/";
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            Map<String, String> h = new HashMap<String, String>();
            String l;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                int c = l.indexOf(':');
                if (c > 0) h.put(l.substring(0, c).trim().toLowerCase(Locale.US), l.substring(c + 1).trim());
            }
            byte[] body = new byte[0];
            String cl = h.get("content-length");
            if (cl != null) {
                int n = Integer.parseInt(cl);
                body = new byte[n];
                int r = 0;
                while (r < n) {
                    int k = in.read(body, r, n - r);
                    if (k < 0) break;
                    r += k;
                }
            }
            String b = new String(body, "UTF-8");
            OutputStream os = s.getOutputStream();

            if (path.equals("/desc.xml")) {
                reply(os, 200, "OK", deviceXml());
            } else if (path.startsWith("/scpd/")) {
                String x = scpdFor(path.substring(6));
                if (x == null) reply(os, 404, "Not Found", ""); else reply(os, 200, "OK", x);
            } else if (method.equals("POST") && path.startsWith("/ctl/")) {
                String sa = h.get("soapaction");
                String res = null;
                if (sa != null) {
                    sa = sa.replace("\"", "").trim();
                    int hash = sa.indexOf('#');
                    if (hash > 0) res = control(sa.substring(0, hash), sa.substring(hash + 1), b);
                }
                if (res == null) reply(os, 500, "Internal Server Error", fault());
                else reply(os, 200, "OK", res);
            } else if (method.equals("SUBSCRIBE")) {
                String m = "HTTP/1.1 200 OK\r\nSID: uuid:" + java.util.UUID.randomUUID() + "\r\nTIMEOUT: Second-1800\r\n"
                        + "Content-Length: 0\r\nConnection: close\r\nSERVER: " + SERVER + "\r\n\r\n";
                os.write(m.getBytes("UTF-8"));
            } else if (method.equals("UNSUBSCRIBE")) {
                os.write("HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes("UTF-8"));
            } else {
                reply(os, 404, "Not Found", "");
            }
            os.flush();
        } catch (Exception e) {
            /* connection dropped */
        } finally {
            try { s.close(); } catch (Exception e) { /* ignore */ }
        }
    }

    private static void reply(OutputStream os, int code, String text, String body) throws Exception {
        byte[] b = body.getBytes("UTF-8");
        String head = "HTTP/1.1 " + code + " " + text + "\r\nContent-Type: text/xml; charset=\"utf-8\"\r\nContent-Length: "
                + b.length + "\r\nConnection: close\r\nSERVER: " + SERVER + "\r\n\r\n";
        os.write(head.getBytes("UTF-8"));
        os.write(b);
    }

    // ---------------- description ----------------

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String unesc(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }

    private static String svc(String type, String id, String n) {
        return "<service><serviceType>" + type + "</serviceType><serviceId>urn:upnp-org:serviceId:" + id
                + "</serviceId><SCPDURL>/scpd/" + n + ".xml</SCPDURL><controlURL>/ctl/" + n
                + "</controlURL><eventSubURL>/evt/" + n + "</eventSubURL></service>";
    }

    private String deviceXml() {
        return "<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\" "
                + "xmlns:dlna=\"urn:schemas-dlna-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion>"
                + "<device><deviceType>" + DEV + "</deviceType><friendlyName>" + esc(name) + "</friendlyName>"
                + "<manufacturer>DlnaTV</manufacturer><modelName>DlnaTV</modelName><modelNumber>1</modelNumber>"
                + "<UDN>uuid:" + uuid + "</UDN><dlna:X_DLNADOC>DMR-1.50</dlna:X_DLNADOC><serviceList>"
                + svc(AVT, "AVTransport", "AVTransport") + svc(RCS, "RenderingControl", "RenderingControl")
                + svc(CMS, "ConnectionManager", "ConnectionManager") + "</serviceList></device></root>";
    }

    private static final String[][] AVT_ACTIONS = {
            {"SetAVTransportURI", "InstanceID,CurrentURI,CurrentURIMetaData", ""},
            {"SetNextAVTransportURI", "InstanceID,NextURI,NextURIMetaData", ""},
            {"GetTransportInfo", "InstanceID", "CurrentTransportState,CurrentTransportStatus,CurrentSpeed"},
            {"GetPositionInfo", "InstanceID", "Track,TrackDuration,TrackMetaData,TrackURI,RelTime,AbsTime,RelCount,AbsCount"},
            {"GetMediaInfo", "InstanceID", "NrTracks,MediaDuration,CurrentURI,CurrentURIMetaData,NextURI,NextURIMetaData,PlayMedium,RecordMedium,WriteStatus"},
            {"GetDeviceCapabilities", "InstanceID", "PlayMedia,RecMedia,RecQualityModes"},
            {"GetTransportSettings", "InstanceID", "PlayMode,RecQualityMode"},
            {"GetCurrentTransportActions", "InstanceID", "Actions"},
            {"Play", "InstanceID,Speed", ""},
            {"Pause", "InstanceID", ""},
            {"Stop", "InstanceID", ""},
            {"Seek", "InstanceID,Unit,Target", ""}};
    private static final String[][] RCS_ACTIONS = {
            {"GetVolume", "InstanceID,Channel", "CurrentVolume"},
            {"SetVolume", "InstanceID,Channel,DesiredVolume", ""},
            {"GetMute", "InstanceID,Channel", "CurrentMute"},
            {"SetMute", "InstanceID,Channel,DesiredMute", ""},
            {"ListPresets", "InstanceID", "CurrentPresetNameList"}};
    private static final String[][] CMS_ACTIONS = {
            {"GetProtocolInfo", "", "Source,Sink"},
            {"GetCurrentConnectionIDs", "", "ConnectionIDs"},
            {"GetCurrentConnectionInfo", "ConnectionID", "RcsID,AVTransportID,ProtocolInfo,PeerConnectionManager,PeerConnectionID,Direction,Status"}};

    private static String scpdFor(String file) {
        if (file.equals("AVTransport.xml")) return scpd(AVT_ACTIONS);
        if (file.equals("RenderingControl.xml")) return scpd(RCS_ACTIONS);
        if (file.equals("ConnectionManager.xml")) return scpd(CMS_ACTIONS);
        return null;
    }

    private static String args(String csv, String dir, Set<String> vars) {
        StringBuilder sb = new StringBuilder();
        if (csv.isEmpty()) return "";
        for (String a : csv.split(",")) {
            vars.add(a);
            sb.append("<argument><name>").append(a).append("</name><direction>").append(dir)
                    .append("</direction><relatedStateVariable>A_ARG_TYPE_").append(a)
                    .append("</relatedStateVariable></argument>");
        }
        return sb.toString();
    }

    private static String scpd(String[][] acts) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\"?><scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">"
                + "<specVersion><major>1</major><minor>0</minor></specVersion><actionList>");
        Set<String> vars = new LinkedHashSet<String>();
        for (String[] a : acts) {
            String ar = args(a[1], "in", vars) + args(a[2], "out", vars);
            sb.append("<action><name>").append(a[0]).append("</name>");
            if (!ar.isEmpty()) sb.append("<argumentList>").append(ar).append("</argumentList>");
            sb.append("</action>");
        }
        sb.append("</actionList><serviceStateTable>");
        for (String v : vars) {
            String t = v.contains("Volume") ? "ui2" : v.contains("Mute") ? "boolean" : "string";
            sb.append("<stateVariable sendEvents=\"no\"><name>A_ARG_TYPE_").append(v).append("</name><dataType>")
                    .append(t).append("</dataType></stateVariable>");
        }
        sb.append("<stateVariable sendEvents=\"yes\"><name>LastChange</name><dataType>string</dataType></stateVariable>");
        sb.append("</serviceStateTable></scpd>");
        return sb.toString();
    }

    // ---------------- SOAP control ----------------

    private static String tag(String body, String n) {
        Matcher m = Pattern.compile("(?s)<(?:\\w+:)?" + n + "[^>]*>(.*?)</(?:\\w+:)?" + n + ">").matcher(body);
        return m.find() ? m.group(1).trim() : "";
    }

    private static String t(String n, Object v) { return "<" + n + ">" + v + "</" + n + ">"; }

    private static String env(String svc, String act, String inner) {
        return "<?xml version=\"1.0\"?>\r\n<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:" + act + "Response xmlns:u=\""
                + svc + "\">" + inner + "</u:" + act + "Response></s:Body></s:Envelope>";
    }

    private static String fault() {
        return "<?xml version=\"1.0\"?>\r\n<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><s:Fault><faultcode>s:Client</faultcode>"
                + "<faultstring>UPnPError</faultstring><detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">"
                + "<errorCode>401</errorCode><errorDescription>Invalid Action</errorDescription></UPnPError></detail>"
                + "</s:Fault></s:Body></s:Envelope>";
    }

    private static String time(long ms) {
        long s = Math.max(0, ms) / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    private static long parseTime(String s) {
        try {
            String[] p = s.split("[:.]");
            return (Long.parseLong(p[0]) * 3600 + Long.parseLong(p[1]) * 60 + Long.parseLong(p[2])) * 1000;
        } catch (Exception e) {
            return 0;
        }
    }

    private String control(String svc, String act, String b) {
        String e = "";
        if (svc.equals(AVT)) {
            if (act.equals("SetAVTransportURI")) { host.setUri(unesc(tag(b, "CurrentURI"))); return env(svc, act, e); }
            if (act.equals("SetNextAVTransportURI")) return env(svc, act, e);
            if (act.equals("Play")) { host.play(); return env(svc, act, e); }
            if (act.equals("Pause")) { host.pause(); return env(svc, act, e); }
            if (act.equals("Stop")) { host.stop(); return env(svc, act, e); }
            if (act.equals("Seek")) { host.seek(parseTime(tag(b, "Target"))); return env(svc, act, e); }
            if (act.equals("GetTransportInfo"))
                return env(svc, act, t("CurrentTransportState", host.state()) + t("CurrentTransportStatus", "OK") + t("CurrentSpeed", "1"));
            if (act.equals("GetPositionInfo"))
                return env(svc, act, t("Track", 1) + t("TrackDuration", time(host.durationMs())) + t("TrackMetaData", "NOT_IMPLEMENTED")
                        + t("TrackURI", esc(host.uri())) + t("RelTime", time(host.positionMs())) + t("AbsTime", time(host.positionMs()))
                        + t("RelCount", 2147483647) + t("AbsCount", 2147483647));
            if (act.equals("GetMediaInfo"))
                return env(svc, act, t("NrTracks", 1) + t("MediaDuration", time(host.durationMs())) + t("CurrentURI", esc(host.uri()))
                        + t("CurrentURIMetaData", "") + t("NextURI", "NOT_IMPLEMENTED") + t("NextURIMetaData", "NOT_IMPLEMENTED")
                        + t("PlayMedium", "NETWORK") + t("RecordMedium", "NOT_IMPLEMENTED") + t("WriteStatus", "NOT_IMPLEMENTED"));
            if (act.equals("GetDeviceCapabilities"))
                return env(svc, act, t("PlayMedia", "NETWORK") + t("RecMedia", "NOT_IMPLEMENTED") + t("RecQualityModes", "NOT_IMPLEMENTED"));
            if (act.equals("GetTransportSettings"))
                return env(svc, act, t("PlayMode", "NORMAL") + t("RecQualityMode", "NOT_IMPLEMENTED"));
            if (act.equals("GetCurrentTransportActions")) return env(svc, act, t("Actions", "Play,Pause,Stop,Seek"));
        } else if (svc.equals(RCS)) {
            if (act.equals("GetVolume")) return env(svc, act, t("CurrentVolume", host.volume()));
            if (act.equals("SetVolume")) {
                try { host.setVolume(Integer.parseInt(tag(b, "DesiredVolume"))); } catch (Exception ex) { /* ignore */ }
                return env(svc, act, e);
            }
            if (act.equals("GetMute")) return env(svc, act, t("CurrentMute", host.mute() ? 1 : 0));
            if (act.equals("SetMute")) {
                String v = tag(b, "DesiredMute");
                host.setMute(v.equals("1") || v.equalsIgnoreCase("true"));
                return env(svc, act, e);
            }
            if (act.equals("ListPresets")) return env(svc, act, t("CurrentPresetNameList", "FactoryDefaults"));
        } else if (svc.equals(CMS)) {
            if (act.equals("GetProtocolInfo")) return env(svc, act, t("Source", "") + t("Sink", SINK));
            if (act.equals("GetCurrentConnectionIDs")) return env(svc, act, t("ConnectionIDs", "0"));
            if (act.equals("GetCurrentConnectionInfo"))
                return env(svc, act, t("RcsID", 0) + t("AVTransportID", 0) + t("ProtocolInfo", "") + t("PeerConnectionManager", "")
                        + t("PeerConnectionID", -1) + t("Direction", "Input") + t("Status", "OK"));
        }
        return null;
    }
}

package app.dlnatv;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.UUID;

public class MainActivity extends Activity implements SurfaceHolder.Callback, Upnp.Host {
    private static final int PORT = 49152;

    private FrameLayout root;
    private SurfaceView sv;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SurfaceHolder holder;
    private MediaPlayer mp;
    private AudioManager am;
    private Upnp upnp;
    private volatile String uri = "";
    private volatile String state = "STOPPED";
    private volatile boolean muted = false;
    private boolean pendingPlay = false;
    private String err = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(26f);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        SharedPreferences p = getSharedPreferences("dlnatv", MODE_PRIVATE);
        String uuid = p.getString("uuid", null);
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
            p.edit().putString("uuid", uuid).commit();
        }
        upnp = new Upnp(this, uuid, "DLNA Screen TV", PORT);
        upnp.start(this);
        showReady();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && android.os.Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        if (upnp != null) upnp.stop();
        super.onDestroy();
    }

    // ---- UI helpers (UI thread) ----

    private void showReady() {
        String e = upnp.error.isEmpty() ? err : upnp.error;
        status.setText("DLNA Screen TV\n\n" + upnp.ip() + "\n\nWaiting for cast..." + (e.isEmpty() ? "" : "\n\n" + e));
        status.setVisibility(View.VISIBLE);
    }

    private void fit(int w, int h) {
        if (w <= 0 || h <= 0) return;
        int rw = Math.max(1, root.getWidth());
        int rh = Math.max(1, root.getHeight());
        float scale = Math.min(rw / (float) w, rh / (float) h);
        sv.setLayoutParams(new FrameLayout.LayoutParams((int) (w * scale), (int) (h * scale), Gravity.CENTER));
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception e) { /* ignore */ }
            try { mp.release(); } catch (Exception e) { /* ignore */ }
            mp = null;
        }
    }

    private void startPlayer() {
        releasePlayer();
        err = "";
        state = "TRANSITIONING";
        status.setText("Connecting...");
        status.setVisibility(View.VISIBLE);
        try {
            mp = new MediaPlayer();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setDisplay(holder);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer m) {
                    m.start();
                    state = "PLAYING";
                    status.setVisibility(View.GONE);
                }
            });
            mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                public void onVideoSizeChanged(MediaPlayer m, int w, int h) { fit(w, h); }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                public boolean onError(MediaPlayer m, int what, int extra) {
                    err = "Playback error " + what + "/" + extra;
                    releasePlayer();
                    state = "STOPPED";
                    showReady();
                    return true;
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) {
                    releasePlayer();
                    state = "STOPPED";
                    showReady();
                }
            });
            mp.setDataSource(uri);
            mp.prepareAsync();
        } catch (Exception e) {
            err = "Cannot play: " + e.getMessage();
            releasePlayer();
            state = "STOPPED";
            showReady();
        }
    }

    private void doPlay() {
        if (mp != null && state.equals("PAUSED_PLAYBACK")) {
            mp.start();
            state = "PLAYING";
            return;
        }
        if (uri.isEmpty()) return;
        if (holder == null) { pendingPlay = true; return; }
        startPlayer();
    }

    // ---- SurfaceHolder.Callback ----

    public void surfaceCreated(SurfaceHolder h) {
        holder = h;
        if (pendingPlay) { pendingPlay = false; doPlay(); }
    }

    public void surfaceChanged(SurfaceHolder h, int format, int w, int h2) { }

    public void surfaceDestroyed(SurfaceHolder h) {
        holder = null;
        releasePlayer();
        state = "STOPPED";
    }

    // ---- Upnp.Host (called from network threads) ----

    public void setUri(String u) {
        uri = u;
        state = "STOPPED";
    }

    public void play() { ui.post(new Runnable() { public void run() { doPlay(); } }); }

    public void pause() {
        ui.post(new Runnable() {
            public void run() {
                if (mp != null && state.equals("PLAYING")) {
                    mp.pause();
                    state = "PAUSED_PLAYBACK";
                }
            }
        });
    }

    public void stop() {
        ui.post(new Runnable() {
            public void run() {
                releasePlayer();
                state = "STOPPED";
                showReady();
            }
        });
    }

    public void seek(final long ms) {
        ui.post(new Runnable() {
            public void run() {
                try { if (mp != null) mp.seekTo((int) ms); } catch (Exception e) { /* live stream */ }
            }
        });
    }

    public String state() { return state; }

    public long positionMs() {
        try { return mp != null ? mp.getCurrentPosition() : 0; } catch (Exception e) { return 0; }
    }

    public long durationMs() {
        try { int d = mp != null ? mp.getDuration() : 0; return d < 0 ? 0 : d; } catch (Exception e) { return 0; }
    }

    public String uri() { return uri; }

    public int volume() {
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max;
    }

    public void setVolume(int v) {
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(100, v)) * max / 100, 0);
    }

    public boolean mute() { return muted; }

    public void setMute(boolean m) {
        muted = m;
        am.setStreamMute(AudioManager.STREAM_MUSIC, m);
    }
}

# DlnaTV

Tiny Java DLNA/UPnP MediaRenderer for Android 4.4+ TVs, built for live screen casting.

* SSDP discovery + AVTransport / RenderingControl / ConnectionManager.
* **Fast mode** (default): reads the MPEG-TS live stream itself (raw socket), demuxes H.264 + AAC and feeds
  MediaCodec directly. No player buffering, old frames are dropped instead of piling up.
* **Compatibility mode**: system MediaPlayer. Used automatically if Fast mode fails or crashed the app last time.
* Audio/video sync is automatic (PTS from the sender clock). Remote: UP toggles Fast / Compatibility mode.

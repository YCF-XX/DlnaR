# DlnaTV

A tiny (Java, no libraries) DLNA/UPnP MediaRenderer for Android 4.4+ TVs.
It announces itself with SSDP, answers AVTransport / RenderingControl / ConnectionManager,
and plays the URL it is sent with the system MediaPlayer (works with HTTP MPEG-TS live streams such as
http://PHONE:8080/live.ts, as well as normal media files).
